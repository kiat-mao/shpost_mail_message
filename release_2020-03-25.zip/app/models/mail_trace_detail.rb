class MailTraceDetail < ApplicationRecord
  belongs_to :mail_trace
end
